var struct_framework___s_w2013_1_1_point =
[
    [ "X", "struct_framework___s_w2013_1_1_point.html#af0677ce380581691d941283fc102fb99", null ],
    [ "Y", "struct_framework___s_w2013_1_1_point.html#a2baad4b964f7fb3ae84ee3e67bef09e1", null ],
    [ "Z", "struct_framework___s_w2013_1_1_point.html#a3c7c3b8b6e456a7621f6379c2248574d", null ]
];