var annotated =
[
    [ "Framework_SW2013", "namespace_framework___s_w2013.html", "namespace_framework___s_w2013" ]
];