var struct_framework___s_w2013_1_1_dimensions =
[
    [ "Ht", "struct_framework___s_w2013_1_1_dimensions.html#a7f64f9319cfa8bb139dd8fba1e076c1c", null ],
    [ "Lg", "struct_framework___s_w2013_1_1_dimensions.html#af2e0054ff78aac40b44106f4aa917737", null ]
];