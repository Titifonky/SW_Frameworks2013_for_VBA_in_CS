var files =
[
    [ "Solidworks", "dir_da4d387531f23a8240d6eccf672f7fa2.html", "dir_da4d387531f23a8240d6eccf672f7fa2" ]
];