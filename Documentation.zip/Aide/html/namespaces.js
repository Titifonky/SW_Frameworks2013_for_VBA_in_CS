var namespaces =
[
    [ "Framework_SW2013", "namespace_framework___s_w2013.html", null ]
];