var searchData=
[
  ['orientation_5fe',['Orientation_e',['../namespace_framework___s_w2013.html#af9f69bbacacd77c3b7526f7d39ba600d',1,'Framework_SW2013']]]
];
