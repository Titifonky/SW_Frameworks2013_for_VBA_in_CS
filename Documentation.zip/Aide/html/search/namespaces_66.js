var searchData=
[
  ['framework_5fsw2013',['Framework_SW2013',['../namespace_framework___s_w2013.html',1,'']]]
];
