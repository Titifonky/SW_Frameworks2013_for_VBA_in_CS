var searchData=
[
  ['init',['Init',['../interface_framework___s_w2013_1_1_i_ext_sld_works.html#a37225fad31f590805e64caedd3cb0db9',1,'Framework_SW2013.IExtSldWorks.Init()'],['../class_framework___s_w2013_1_1_ext_sld_works.html#a5dbc504422d6d3c46c57b1d8d8139022',1,'Framework_SW2013.ExtSldWorks.Init()']]]
];
