var searchData=
[
  ['dimensions',['Dimensions',['../struct_framework___s_w2013_1_1_dimensions.html',1,'Framework_SW2013']]]
];
