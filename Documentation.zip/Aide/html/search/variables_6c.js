var searchData=
[
  ['lg',['Lg',['../struct_framework___s_w2013_1_1_dimensions.html#af2e0054ff78aac40b44106f4aa917737',1,'Framework_SW2013::Dimensions']]]
];
